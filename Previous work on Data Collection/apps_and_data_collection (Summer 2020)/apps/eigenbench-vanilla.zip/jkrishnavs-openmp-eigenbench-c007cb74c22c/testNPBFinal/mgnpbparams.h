/* CLASS = A */
/*
c  This file is generated automatically by the setparams utility.
c  It sets the number of processors and the class of the NPB
c  in this directory. Do not modify it by hand.
*/
#define	NX_DEFAULT	256
#define	NY_DEFAULT	256
#define	NZ_DEFAULT	256
#define	NIT_DEFAULT	4
#define	LM	8
#define	LT_DEFAULT	8
#define	DEBUG_DEFAULT	0
#define	NDIM1	8
#define	NDIM2	8
#define	NDIM3	8
#define	CONVERTDOUBLE	FALSE
#define COMPILETIME "10 Sep 2016"
#define NPBVERSION "2.3"
#define CS1 "gcc"
#define CS2 "g++"
#define CS3 "-lenergymodule"
#define CS4 "-I../common -I../../../workspace/testmonito..."
#define CS5 "-O3 -lm -fopenmp -lenergymodule "
#define CS6 "(none)"
#define CS7 "randdp"
