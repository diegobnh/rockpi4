#define CLASS 'A'
/*
   This file is generated automatically by the setparams utility.
   It sets the number of processors and the class of the NPB
   in this directory. Do not modify it by hand.   */
   
#define COMPILETIME "10 Sep 2016"
#define NPBVERSION "2.3"
#define CC "gcc"
#define CFLAGS "-O3 -lm -fopenmp -lenergymodule "
#define CLINK "g++"
#define CLINKFLAGS "(none)"
#define C_LIB "-lenergymodule"
#define C_INC "-I../common -I../../../workspace/testmonito..."
