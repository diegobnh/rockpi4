/* CLASS = A */
/*
c  This file is generated automatically by the setparams utility.
c  It sets the number of processors and the class of the NPB
c  in this directory. Do not modify it by hand.
*/
#define	PROBLEM_SIZE	64
#define	NITER_DEFAULT	200
#define	DT_DEFAULT	0.0008
#define	CONVERTDOUBLE	FALSE
#define COMPILETIME "10 Sep 2016"
#define NPBVERSION "2.3"
#define CS1 "gcc"
#define CS2 "g++"
#define CS3 "-lenergymodule"
#define CS4 "-I../common -I../../../workspace/testmonito..."
#define CS5 "-O3 -lm -fopenmp -lenergymodule "
#define CS6 "(none)"
#define CS7 "randdp"
